package com.techcom.live

enum class StreamMode(val label: String) {
    VIDEO_LOOP("Video Loop"), VIDEO_LIVE("Video Live"), CAMERA("Camera"), SCREEN("Screen");

    val usesFile get() = this == VIDEO_LOOP || this == VIDEO_LIVE

    companion object { fun parse(s: String?) = values().firstOrNull { it.label == s } ?: CAMERA }
}

enum class Fit { FIT, FILL }
enum class ScreenAudio { MIC, SYSTEM, MUTED }
enum class LiveState(val label: String) {
    OFFLINE("Offline"), CONNECTING("Connecting"), LIVE("Live"), RECONNECTING("Reconnecting"), ERROR("Error")
}

data class StreamConfig(
    val mode: StreamMode = StreamMode.CAMERA,
    val ratio: String = "16:9",          // "16:9", "9:16", "1:1", "4:3"
    val res: String = "720p",            // short side: 480p / 720p / 1080p
    val fps: Int = 30,
    val kbps: Int = 4500,
    val audioKbps: Int = 128,
    val sampleRate: Int = 44100,
    val audioOn: Boolean = true,
    val screenAudio: ScreenAudio = ScreenAudio.MIC,
    val fit: Fit = Fit.FIT,
    val repeat: Boolean = true,
    val shuffle: Boolean = false,
    val frontCamera: Boolean = false,
    val notifications: Boolean = true,
    val retries: Int = 0,                // reconnect attempts; 0 = keep trying until stopped
) {
    private val side get() = res.removeSuffix("p").toIntOrNull() ?: 720
    private val r: Double get() {
        val p = ratio.split(":")
        val a = p.getOrNull(0)?.toDoubleOrNull() ?: 16.0
        val b = p.getOrNull(1)?.toDoubleOrNull() ?: 9.0
        return if (b == 0.0) 16.0 / 9.0 else a / b
    }
    val portrait get() = r < 1.0
    val width: Int get() = if (r >= 1.0) (Math.round(side * r / 2.0) * 2).toInt() else side
    val height: Int get() = if (r >= 1.0) side else (Math.round(side / r / 2.0) * 2).toInt()
}

data class KeepAlive(val fg: Boolean = false, val wake: Boolean = false, val wifi: Boolean = false)

data class PlaylistItem(
    val uri: String,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
)

data class FileProgress(
    val name: String,
    val positionMs: Long,
    val durationMs: Long,
    val pass: Int,
    val index: Int,
    val count: Int,
)

/** Handed from the UI layer to the service in memory only; the stream key is never put in an Intent. */
data class PendingStart(
    val cfg: StreamConfig,
    val serverUrl: String,
    val streamKey: String,
    val playlist: List<PlaylistItem>,
)
