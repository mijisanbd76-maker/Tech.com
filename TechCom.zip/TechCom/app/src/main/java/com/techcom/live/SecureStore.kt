package com.techcom.live

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stream key lives only in Android-Keystore-backed encrypted storage. If that is unavailable, nothing is saved. */
class SecureStore(ctx: Context) {
    private val sp: SharedPreferences? = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "techcom_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) { null }

    fun key(): String = sp?.getString("stream_key", "") ?: ""
    fun saveKey(k: String): Boolean {
        val s = sp ?: return false
        s.edit().putString("stream_key", k.trim()).apply(); return true
    }
}
