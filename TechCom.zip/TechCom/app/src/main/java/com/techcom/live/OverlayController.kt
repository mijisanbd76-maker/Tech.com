package com.techcom.live

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** A tiny floating logo shown over the game. Tap it to open Start / Stop, drag it to move it. */
class OverlayController(
    private val ctx: Context,
    private val onStart: () -> Unit,
    private val onStop: () -> Unit,
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var logo: ImageView? = null
    private var panel: LinearLayout? = null
    private var startBtn: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var live = false

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    private fun button(label: String, color: Int, action: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(11), dp(14), dp(11))
        val bg = GradientDrawable()
        bg.setColor(color)
        bg.cornerRadius = dp(10).toFloat()
        t.background = bg
        t.setOnClickListener { action() }
        return t
    }

    /** Returns false when Android does not allow drawing over other apps. */
    @SuppressLint("ClickableViewAccessibility")
    fun show(): Boolean {
        if (root != null) return true
        return try {
            val lg = ImageView(ctx)
            lg.setImageResource(R.drawable.logo)
            lg.scaleType = ImageView.ScaleType.FIT_CENTER
            lg.setPadding(dp(5), dp(5), dp(5), dp(5))
            val lgBg = GradientDrawable()
            lgBg.shape = GradientDrawable.OVAL
            lgBg.setColor(Color.parseColor("#E60E1630"))
            lgBg.setStroke(dp(2), Color.parseColor("#22D3EE"))
            lg.background = lgBg
            lg.alpha = 0.92f

            val start = button("\u25B6  Start live", Color.parseColor("#16A34A")) { startLive() }
            val stop = button("\u25A0  Stop live", Color.parseColor("#DC2626")) { onStop() }
            val pn = LinearLayout(ctx)
            pn.orientation = LinearLayout.VERTICAL
            pn.setPadding(dp(8), dp(8), dp(8), dp(8))
            val pnBg = GradientDrawable()
            pnBg.setColor(Color.parseColor("#F20E1630"))
            pnBg.cornerRadius = dp(14).toFloat()
            pn.background = pnBg
            pn.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val lpStop = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lpStop.topMargin = dp(8)
            pn.addView(stop, lpStop)
            pn.visibility = View.GONE

            val rt = LinearLayout(ctx)
            rt.orientation = LinearLayout.VERTICAL
            rt.addView(lg, LinearLayout.LayoutParams(dp(46), dp(46)))
            val lpPanel = LinearLayout.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT)
            lpPanel.topMargin = dp(6)
            rt.addView(pn, lpPanel)

            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            )
            p.gravity = Gravity.TOP or Gravity.START
            p.x = dp(8)
            p.y = dp(140)

            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            lg.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; moved = false; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                        if (moved) {
                            p.x = startX + dx.toInt(); p.y = startY + dy.toInt()
                            try { wm.updateViewLayout(rt, p) } catch (_: Exception) { }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                    else -> false
                }
            }

            wm.addView(rt, p)
            root = rt; logo = lg; panel = pn; startBtn = start; params = p
            true
        } catch (e: Throwable) { false }
    }

    private fun togglePanel() {
        val pn = panel ?: return
        pn.visibility = if (pn.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
    }

    private fun startLive() {
        if (live) return
        live = true
        panel?.visibility = View.GONE
        // After Start the logo shrinks and fades so it hardly shows in the stream.
        logo?.let { it.layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)); it.alpha = 0.4f }
        startBtn?.alpha = 0.4f
        try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
        onStart()
    }

    fun hide() {
        val r = root
        if (r != null) { try { wm.removeView(r) } catch (_: Exception) { } }
        root = null; logo = null; panel = null; startBtn = null; params = null
    }
}
