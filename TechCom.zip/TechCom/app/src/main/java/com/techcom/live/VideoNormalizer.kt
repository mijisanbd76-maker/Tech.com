package com.techcom.live

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.File
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Proxy

/**
 * Many phone / editor videos are stored sideways (e.g. 1920x1080 + "rotate 90"). The live engine reads the raw size, so a
 * vertical video was drawn as a squashed 16:9 band in the middle of the vertical live. This class re-encodes such a video
 * ONCE to the exact live size (e.g. 720x1280, upright, no rotation flag) with Media3 Transformer, so the live engine receives
 * frames that already have the right shape. Everything is called through reflection: if anything is missing the caller simply
 * keeps the original file (nothing can fail to compile or crash because of this class).
 */
class VideoNormalizer(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var transformer: Any? = null
    @Volatile private var cancelled = false

    data class Probe(val w: Int, val h: Int, val rot: Int, val durMs: Long)

    private val dir: File get() = File(ctx.cacheDir, "norm").also { it.mkdirs() }

    fun probe(uri: Uri): Probe? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (w <= 0 || h <= 0) null else Probe(w, h, ((rot % 360) + 360) % 360, dur)
        } catch (e: Exception) { null } finally { try { r.release() } catch (_: Exception) { } }
    }

    /** True when the file does not already have exactly the live size (or is stored rotated). */
    fun needs(p: Probe, cw: Int, ch: Int): Boolean {
        if (p.rot == 0 && p.w == cw && p.h == ch) return false
        if (p.rot == 0 && p.durMs > 30L * 60L * 1000L) return false   // very long upright files: use as they are
        return true
    }

    fun cacheFile(uri: Uri, cw: Int, ch: Int, fill: Boolean, p: Probe): File {
        val key = Integer.toHexString(uri.toString().hashCode())
        return File(dir, "n_${key}_${cw}x${ch}_${if (fill) "fill" else "fit"}_${p.durMs}.mp4")
    }

    /** Deletes older prepared files that are not part of the current playlist. */
    fun prune(keep: Set<String>) {
        try { dir.listFiles()?.forEach { if (it.name !in keep) it.delete() } } catch (_: Exception) { }
    }

    fun cancel() {
        cancelled = true
        try { transformer?.let { it.javaClass.getMethod("cancel").invoke(it) } } catch (_: Throwable) { }
        transformer = null
    }

    /** Must be called on the main thread. [done] gets null on success or an error text. */
    fun run(uri: Uri, w: Int, h: Int, fill: Boolean, out: File, onProgress: (Int) -> Unit, done: (String?) -> Unit) {
        cancelled = false
        val part = File(out.path + ".part")
        try { part.delete() } catch (_: Exception) { }
        var finished = false
        fun finish(err: String?) {
            if (finished) return
            finished = true
            transformer = null
            if (err == null) {
                val ok = try { part.exists() && part.length() > 0 && part.renameTo(out) } catch (_: Exception) { false }
                done(if (ok) null else "prepared file is empty")
            } else { try { part.delete() } catch (_: Exception) { }; done(err) }
        }
        try {
            val miCls = Class.forName("androidx.media3.common.MediaItem")
            val mediaItem = miCls.getMethod("fromUri", Uri::class.java).invoke(null, uri)

            val presCls = Class.forName("androidx.media3.effect.Presentation")
            val layout = presCls.getField(if (fill) "LAYOUT_SCALE_TO_FIT_WITH_CROP" else "LAYOUT_SCALE_TO_FIT").getInt(null)
            val intT = Int::class.javaPrimitiveType
            val presentation = presCls.getMethod("createForWidthAndHeight", intT, intT, intT).invoke(null, w, h, layout)

            val effectsCls = Class.forName("androidx.media3.transformer.Effects")
            val effects = effectsCls.getConstructor(List::class.java, List::class.java).newInstance(emptyList<Any>(), listOf(presentation))

            val emiCls = Class.forName("androidx.media3.transformer.EditedMediaItem")
            val emiB = Class.forName("androidx.media3.transformer.EditedMediaItem\$Builder")
            val b = emiB.getConstructor(miCls).newInstance(mediaItem)
            emiB.getMethod("setEffects", effectsCls).invoke(b, effects)
            val edited = emiB.getMethod("build").invoke(b)

            val listenerCls = Class.forName("androidx.media3.transformer.Transformer\$Listener")
            val handler = InvocationHandler { proxy, m, args ->
                when (m.name) {
                    "onCompleted" -> { main.post { finish(null) }; null }
                    "onError" -> {
                        val msg = try { (args?.getOrNull(2) as? Throwable)?.message } catch (_: Throwable) { null }
                        main.post { finish(if (cancelled) "cancelled" else (msg ?: "transform error")) }
                        null
                    }
                    "hashCode" -> System.identityHashCode(proxy)
                    "equals" -> proxy === args?.getOrNull(0)
                    "toString" -> "TechComTransformListener"
                    else -> null
                }
            }
            val listener = Proxy.newProxyInstance(listenerCls.classLoader, arrayOf(listenerCls), handler)

            val trB = Class.forName("androidx.media3.transformer.Transformer\$Builder")
            val tb = trB.getConstructor(Context::class.java).newInstance(ctx)
            trB.getMethod("setVideoMimeType", String::class.java).invoke(tb, "video/avc")
            trB.getMethod("setAudioMimeType", String::class.java).invoke(tb, "audio/mp4a-latm")
            trB.getMethod("addListener", listenerCls).invoke(tb, listener)
            val tr = trB.getMethod("build").invoke(tb) ?: throw IllegalStateException("no transformer")
            transformer = tr
            tr.javaClass.getMethod("start", emiCls, String::class.java).invoke(tr, edited, part.absolutePath)

            // progress polling
            val phCls = Class.forName("androidx.media3.transformer.ProgressHolder")
            val ph = phCls.getConstructor().newInstance()
            val getProgress = tr.javaClass.getMethod("getProgress", phCls)
            val progField = phCls.getField("progress")
            val poll = object : Runnable {
                override fun run() {
                    if (finished || cancelled) return
                    try { getProgress.invoke(tr, ph); onProgress(progField.getInt(ph)) } catch (_: Throwable) { }
                    main.postDelayed(this, 800)
                }
            }
            main.postDelayed(poll, 800)
        } catch (e: Throwable) {
            val c = e.cause ?: e
            finish("${c.javaClass.simpleName}: ${c.message ?: ""}")
        }
    }
}
