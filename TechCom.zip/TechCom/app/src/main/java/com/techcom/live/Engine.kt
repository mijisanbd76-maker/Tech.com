package com.techcom.live

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.SurfaceView
import com.pedro.common.ConnectChecker
import com.pedro.library.generic.GenericStream
import com.pedro.encoder.input.sources.audio.AudioFileSource
import com.pedro.encoder.input.sources.audio.InternalAudioSource
import com.pedro.encoder.input.sources.audio.MicrophoneSource
import com.pedro.encoder.input.sources.video.Camera2Source
import com.pedro.encoder.input.sources.video.ScreenSource
import com.pedro.encoder.input.sources.video.VideoFileSource
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

/** Single source of truth for what the UI shows. Only real values are ever written here. */
object Runtime {
    val state = MutableStateFlow(LiveState.OFFLINE)
    val error = MutableStateFlow<String?>(null)
    val bitrateKbps = MutableStateFlow<Long?>(null)      // measured by the RTMP sender; null until first sample
    val startedAtMs = MutableStateFlow(0L)                // wall clock when the stream became LIVE; 0 = not live
    val muted = MutableStateFlow(false)
    val file = MutableStateFlow<FileProgress?>(null)
    val active = MutableStateFlow<StreamConfig?>(null)
    val network = MutableStateFlow("Checking…")
    val result = MutableStateFlow<String?>(null)
    val log = MutableStateFlow<List<String>>(emptyList())
    val keep = MutableStateFlow(KeepAlive())
    val hint = MutableStateFlow<String?>(null)            // non-fatal notices (e.g. fit mode unsupported)
    @Volatile var pending: PendingStart? = null
}

object EngineHolder {
    @Volatile private var inst: StreamEngine? = null
    fun get(ctx: Context): StreamEngine = inst ?: synchronized(this) {
        inst ?: StreamEngine(ctx.applicationContext).also { inst = it }
    }
}

/**
 * The RootEncoder file-source classes (VideoFileSource / AudioFileSource) exist since library 2.3.8, but their
 * "load this file" method differs between library versions. We probe the public API at runtime and report a clear
 * error instead of crashing, so a mismatch can never look like a successful stream.
 */
object FileBridge {
    private val loadNames = listOf("prepare", "setFile", "setUri", "setPath", "load", "setSource", "init")

    fun load(src: Any, ctx: Context, uri: Uri): Boolean {
        for (m in src.javaClass.methods) {
            if (m.name !in loadNames) continue
            val p = m.parameterTypes
            val args: Array<Any?> = when {
                p.size == 2 && p[0] == Context::class.java && p[1] == Uri::class.java -> arrayOf(ctx, uri)
                p.size == 2 && p[0] == Context::class.java && p[1] == String::class.java -> arrayOf(ctx, uri.toString())
                p.size == 1 && p[0] == Uri::class.java -> arrayOf(uri)
                p.size == 1 && p[0] == String::class.java -> arrayOf(uri.toString())
                else -> continue
            }
            try {
                val r = m.invoke(src, *args)
                if (r == null || r == true || r == Unit) return true
            } catch (_: Exception) { }
        }
        return false
    }

    /** Applies Fit/Fill on the GL renderer when this library version exposes it. */
    fun setAspect(gl: Any?, fill: Boolean): Boolean {
        if (gl == null) return false
        for (m in gl.javaClass.methods) {
            if (m.name != "setAspectRatioMode" || m.parameterTypes.size != 1 || !m.parameterTypes[0].isEnum) continue
            val consts = m.parameterTypes[0].enumConstants ?: continue
            val want = if (fill) "Fill" else "Adjust"
            val c = consts.firstOrNull { it.toString().equals(want, true) } ?: continue
            return try { m.invoke(gl, c); true } catch (_: Exception) { false }
        }
        return false
    }
}

object VideoInfo {
    fun read(ctx: Context, uri: Uri): PlaylistItem? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            var name = "video"; var size = 0L
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0) size = c.getLong(si)
                }
            }
            if (dur <= 0 || w <= 0) null else PlaylistItem(uri.toString(), name, dur, size, w, h)
        } catch (e: Exception) { null } finally { try { r.release() } catch (_: Exception) { } }
    }
}

class StreamEngine(private val app: Context) : ConnectChecker {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var stream: GenericStream? = null
    private var pendingUri: Uri = Uri.EMPTY
    private var sig: String? = null
    private var projection: MediaProjection? = null
    private var cfg: StreamConfig? = null
    private var endpoint: String? = null
    private var secret: String = ""
    private var userStop = false
    private var attempts = 0
    private var maxRetries = Int.MAX_VALUE
    private var sessionStart = 0L
    private var job: Job? = null
    private var retryJob: Job? = null
    private var preview: SurfaceView? = null
    var onFinished: (() -> Unit)? = null
    private val clock = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)

    /** Connection log shown in the app. Never contains the stream key (redacted). */
    private fun logEv(msg: String) {
        val line = clock.format(java.util.Date()) + " " + redact(msg)
        Runtime.log.value = (Runtime.log.value + line).takeLast(40)
    }

    val isStreaming get() = stream?.isStreaming == true

    // ---- preparing -------------------------------------------------------------------------------------------

    /** Builds (or reuses) the encoder pipeline. Returns an error message, or null when ready. */
    fun prepare(c: StreamConfig, mp: MediaProjection?): String? {
        val newSig = "${c.mode}|${c.width}x${c.height}|${c.fps}|${c.kbps}|${c.audioKbps}|${c.sampleRate}|${c.screenAudio}|${c.audioOn}|${c.ratio}|${c.fit}"
        if (stream != null && newSig == sig && c.mode != StreamMode.SCREEN) return null
        if (isStreaming) return "Stop the current stream before changing settings."
        releaseStream()
        return try {
            val s: GenericStream = when (c.mode) {
                StreamMode.CAMERA -> GenericStream(app, this, Camera2Source(app), MicrophoneSource())
                StreamMode.SCREEN -> {
                    val p = mp ?: return "Screen capture permission is missing."
                    projection = p
                    val audio = if (c.screenAudio == ScreenAudio.SYSTEM) {
                        if (Build.VERSION.SDK_INT < 29) return "System audio capture needs Android 10 or newer."
                        InternalAudioSource(p)
                    } else MicrophoneSource()
                    GenericStream(app, this, ScreenSource(app, p), audio)
                }
                else -> {
                    if (c.audioOn) GenericStream(app, this, VideoFileSource(app, pendingUri), AudioFileSource(app, pendingUri))
                    else GenericStream(app, this, VideoFileSource(app, pendingUri), MicrophoneSource())
                }
            }
            // Camera frames are delivered in sensor (landscape) orientation; portrait output is produced by rotating 90°.
            val cam = c.mode == StreamMode.CAMERA
            val vw = if (cam) maxOf(c.width, c.height) else c.width
            val vh = if (cam) minOf(c.width, c.height) else c.height
            val rot = if (cam && c.portrait) 90 else 0
            val vk = safeKbps(c)
            if (vk < c.kbps) logEv("Video bitrate set to $vk kbps (best for ${c.res} ${c.fps}fps, keeps the sound clear)")
            targetBps = vk * 1000; curBps = targetBps; calm = 0
            val okV = s.prepareVideo(vw, vh, vk * 1000, fps = c.fps, iFrameInterval = 2, rotation = rot)
            val micAudio = s.audioSource is MicrophoneSource
            val fa = if (c.mode.usesFile && c.audioOn) audioInfo(pendingUri) else null
            val aRate = if (c.mode.usesFile) (fa?.first ?: c.sampleRate) else 48000
            val aStereo = if (fa != null) fa.second >= 2 else !micAudio
            val aKbps = if (c.mode == StreamMode.SCREEN && !micAudio) maxOf(c.audioKbps, 192) else maxOf(c.audioKbps, 128)
            val okA = s.prepareAudio(aRate, aStereo, aKbps * 1000)
            logEv("Audio: " + (if (c.mode.usesFile && c.audioOn) "video file" else if (micAudio) "microphone" else "system (playback capture)") + " ${aRate / 1000} kHz " + (if (aStereo) "stereo" else "mono") + " $aKbps kbps")
            if (!okV || !okA) {
                try { s.release() } catch (_: Exception) { }
                return "This phone's encoder rejected ${c.res} ${c.fps}fps. Try a lower resolution or frame rate."
            }
            if (!FileBridge.setAspect(try { s.getGlInterface() } catch (_: Throwable) { null }, c.fit == Fit.FILL)) {
                Runtime.hint.value = "Fit/Fill mode is not available in this encoder version; default fit is used."
            }
            if (c.mode == StreamMode.CAMERA && c.frontCamera) {
                try { (s.videoSource as Camera2Source).switchCamera() } catch (_: Exception) { }
            }
            if (!c.audioOn || (c.mode == StreamMode.CAMERA && Runtime.muted.value)) muteMic(s, true)
            stream = s; sig = newSig; cfg = c
            preview?.let { try { s.startPreview(it) } catch (_: Exception) { } }
            null
        } catch (e: Exception) {
            releaseStream()
            "Could not initialise encoders: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun muteMic(s: GenericStream, mute: Boolean) {
        try {
            val a = s.audioSource as? MicrophoneSource ?: return
            if (mute) a.mute() else a.unMute()
        } catch (_: Exception) { }
    }

    // ---- crop / zoom (screen) ------------------------------------------------------------------------------
    @Volatile private var cropZoom = 1f
    @Volatile private var cropX = 50f
    @Volatile private var cropY = 50f
    private var cropFilter: Any? = null
    private var cropAdded = false

    /** Zoom into the picture. zoom 1 = full screen; pan values are 0..100 (50 = centre). */
    fun applyCrop(z: Float, px: Float, py: Float): Boolean {
        cropZoom = z.coerceIn(1f, 4f); cropX = px.coerceIn(0f, 100f); cropY = py.coerceIn(0f, 100f)
        val s = stream ?: return false
        return try {
            val gl = s.getGlInterface()
            val cls = Class.forName("com.pedro.encoder.input.gl.render.filters.CropFilterRender")
            val f = cropFilter ?: cls.getDeclaredConstructor().newInstance().also { cropFilter = it }
            val w = 100f / cropZoom
            val offX = (100f - w) * cropX / 100f
            val offY = (100f - w) * cropY / 100f
            cls.methods.first { it.name == "setCropArea" && it.parameterTypes.size == 4 }.invoke(f, offX, offY, w, w)
            if (!cropAdded) {
                gl.javaClass.methods.first { it.name == "setFilter" && it.parameterTypes.size == 1 && it.parameterTypes[0].isAssignableFrom(cls) }.invoke(gl, f)
                cropAdded = true
            }
            true
        } catch (e: Throwable) {
            Runtime.hint.value = "Zoom is not available in this encoder version."
            false
        }
    }

    // ---- smooth audio / video helpers ----------------------------------------------------------------------
    /** (sampleRate, channels) of the first audio track of a picked video, or null when unknown. */
    private fun audioInfo(uri: Uri): Pair<Int, Int>? {
        val ex = android.media.MediaExtractor()
        return try {
            ex.setDataSource(app, uri, null)
            var r: Pair<Int, Int>? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(android.media.MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    r = Pair(f.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE), f.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT))
                    break
                }
            }
            r
        } catch (e: Exception) { null } finally { try { ex.release() } catch (_: Exception) { } }
    }

    /** Live video above what the network can carry makes the sound stutter, so cap to YouTube's recommended maximum. */
    private fun safeKbps(c: StreamConfig): Int {
        if (c.mode.usesFile) return c.kbps
        val side = minOf(c.width, c.height)
        val hi = c.fps > 30
        val cap = when {
            side >= 1080 -> if (hi) 9000 else 6000
            side >= 720 -> if (hi) 6000 else 4000
            else -> if (hi) 3000 else 2000
        }
        return minOf(c.kbps, cap)
    }

    private var targetBps = 0
    private var curBps = 0
    private var calm = 0

    /** A larger send queue (about 8 s) lets short network hiccups pass without dropping audio frames. Best effort. */
    private fun widenSendQueue() {
        try {
            val s = stream ?: return
            val sc = s.javaClass.getMethod("getStreamClient").invoke(s) ?: return
            val m = sc.javaClass.methods.firstOrNull { it.name == "resizeCache" && it.parameterTypes.size == 1 && it.parameterTypes[0] == Int::class.javaPrimitiveType } ?: return
            m.invoke(sc, 600)
        } catch (_: Throwable) { }
    }

    /** When the upload cannot keep up, lower the video bitrate (and raise it again later) so audio is never starved. */
    private fun adaptBitrate() {
        try {
            val s = stream ?: return
            if (!s.isStreaming || targetBps <= 0) return
            val sc = s.javaClass.getMethod("getStreamClient").invoke(s) ?: return
            val hm = sc.javaClass.methods.firstOrNull { it.name == "hasCongestion" && it.parameterTypes.size == 1 } ?: return
            val congested = hm.invoke(sc, 20f) as? Boolean ?: return
            val setter = s.javaClass.methods.firstOrNull { it.name == "setVideoBitrateOnFly" && it.parameterTypes.size == 1 } ?: return
            if (congested) {
                calm = 0
                val n = maxOf(targetBps * 4 / 10, curBps * 8 / 10)
                if (n < curBps) {
                    curBps = n; setter.invoke(s, curBps)
                    main.post { logEv("Slow upload: video lowered to ${curBps / 1000} kbps to keep the sound clear") }
                }
            } else if (curBps < targetBps) {
                calm++
                if (calm >= 20) { calm = 0; curBps = minOf(targetBps, curBps * 11 / 10); setter.invoke(s, curBps) }
            }
        } catch (_: Throwable) { }
    }

    // ---- soft blur for the first seconds of a screen live ------------------------------------------------------
    private var blurFilter: Any? = null
    private var blurActive = false

    private fun blurOn() {
        try {
            val s = stream ?: return
            val gl = s.getGlInterface()
            val cls = Class.forName("com.pedro.encoder.input.gl.render.filters.BlurFilterRender")
            val f = blurFilter ?: cls.getDeclaredConstructor().newInstance().also { blurFilter = it }
            try { cls.methods.firstOrNull { it.name == "setBlurRadius" && it.parameterTypes.size == 1 }?.invoke(f, 12) } catch (_: Throwable) { }
            gl.javaClass.methods.first { it.name == "addFilter" && it.parameterTypes.size == 1 && it.parameterTypes[0].isAssignableFrom(cls) }.invoke(gl, f)
            blurActive = true
        } catch (_: Throwable) { blurActive = false }
    }

    private fun blurOff() {
        if (!blurActive) return
        try {
            val s = stream ?: return
            val gl = s.getGlInterface()
            val f = blurFilter ?: return
            gl.javaClass.methods.first { it.name == "removeFilter" && it.parameterTypes.size == 1 && it.parameterTypes[0].isAssignableFrom(f.javaClass) }.invoke(gl, f)
        } catch (_: Throwable) { }
        blurActive = false
    }

    fun toggleMute(): Boolean {
        val s = stream ?: return false
        if (s.audioSource !is MicrophoneSource) return false
        val m = !Runtime.muted.value
        muteMic(s, m); Runtime.muted.value = m
        return true
    }

    fun switchCamera(): Boolean = try {
        (stream?.videoSource as? Camera2Source)?.switchCamera(); stream?.videoSource is Camera2Source
    } catch (_: Exception) { false }

    // ---- preview ---------------------------------------------------------------------------------------------

    fun attachPreview(v: SurfaceView) {
        preview = v
        val s = stream ?: return
        try { if (s.isOnPreview) s.stopPreview(); s.startPreview(v) } catch (_: Exception) { }
    }

    fun detachPreview() {
        preview = null
        try { stream?.let { if (it.isOnPreview) it.stopPreview() } } catch (_: Exception) { }
    }

    fun releaseIfIdle() { if (!isStreaming && Runtime.state.value == LiveState.OFFLINE) releaseStream() }

    // ---- start / stop ----------------------------------------------------------------------------------------

    fun begin(p: PendingStart, mp: MediaProjection?) {
        userStop = false; attempts = 0
        maxRetries = if (p.cfg.retries <= 0) Int.MAX_VALUE else p.cfg.retries
        Runtime.error.value = null; Runtime.hint.value = null; Runtime.result.value = null
        Runtime.log.value = emptyList()
        Runtime.bitrateKbps.value = null; Runtime.startedAtMs.value = 0L; Runtime.file.value = null
        Runtime.state.value = LiveState.CONNECTING
        Runtime.active.value = p.cfg
        secret = p.streamKey
        logEv("Preparing ${p.cfg.mode.label} ${p.cfg.width}x${p.cfg.height} ${p.cfg.fps}fps ${p.cfg.kbps}kbps")
        sessionStart = System.currentTimeMillis()
        pendingUri = p.playlist.firstOrNull()?.let { Uri.parse(it.uri) } ?: Uri.EMPTY
        val err = prepare(p.cfg, mp)
        val s = stream
        if (err != null || s == null) { logEv("Encoder error: " + (err ?: "not ready")); fail(err ?: "Encoder not ready."); return }
        logEv("Encoders ready")
        if (p.cfg.mode == StreamMode.SCREEN) { if (p.cfg.zoom > 1.01f) applyCrop(p.cfg.zoom, p.cfg.panX, p.cfg.panY); blurOn() }
        endpoint = p.serverUrl.trimEnd('/') + "/" + p.streamKey.trim()
        if (p.cfg.mode.usesFile) {
            val first = p.playlist.firstOrNull() ?: run { fail("No video selected."); return }
            val order = if (p.cfg.mode == StreamMode.VIDEO_LOOP && p.cfg.shuffle) p.playlist.shuffled() else p.playlist
            if (!loadInto(s, order.first())) {
                fail("This build of the encoder library could not open the video file. See README → 'File source check'."); return
            }
            runPlaylist(order, p, s)
        }
        logEv("Connecting to " + hostOf(p.serverUrl))
        try { s.startStream(endpoint!!) } catch (e: Exception) { fail("Could not start: ${redact(e.message)}") }
    }

    private fun loadInto(s: GenericStream, item: PlaylistItem): Boolean {
        val uri = Uri.parse(item.uri)
        val v = s.videoSource; val a = s.audioSource
        return true
    }

    private fun switchTo(s: GenericStream, item: PlaylistItem): Boolean = try {
        val uri = Uri.parse(item.uri)
        val v = VideoFileSource(app, uri); val a = AudioFileSource(app, uri)
        if (false) false
        else { s.changeVideoSource(v); if (s.audioSource !is MicrophoneSource) s.changeAudioSource(a); true }
    } catch (e: Exception) { false }

    private fun runPlaylist(initial: List<PlaylistItem>, p: PendingStart, s: GenericStream) {
        job?.cancel()
        job = scope.launch {
            var order = initial; var i = 0; var pass = 1
            val loop = p.cfg.mode == StreamMode.VIDEO_LOOP && p.cfg.repeat
            while (isActive) {
                val item = order[i]
                var pos = 0L
                Runtime.file.value = FileProgress(item.name, 0, item.durationMs, pass, i + 1, order.size)
                var last = SystemClock.elapsedRealtime()
                while (isActive && pos < item.durationMs) {
                    delay(500)
                    val now = SystemClock.elapsedRealtime()
                    if (Runtime.state.value == LiveState.LIVE) pos += now - last   // only count time that was really on air
                    last = now
                    Runtime.file.value = FileProgress(item.name, minOf(pos, item.durationMs), item.durationMs, pass, i + 1, order.size)
                }
                if (!isActive) return@launch
                i++
                if (i >= order.size) {
                    if (!loop) { finish("Completed", null); return@launch }
                    pass++; i = 0
                    if (p.cfg.shuffle) order = initial.shuffled()
                }
                if (!switchTo(s, order[i])) { fail("Could not load the next video in the playlist."); return@launch }
            }
        }
    }

    fun stop(reason: String = "Stopped by user") { userStop = true; finish(reason, null) }

    private fun fail(msg: String) {
        Runtime.error.value = msg
        Runtime.state.value = LiveState.ERROR
        finish(null, msg)
    }

    /** Always releases every resource, records history, then notifies the service. */
    private fun finish(result: String?, error: String?) {
        job?.cancel(); retryJob?.cancel()
        val c = cfg ?: Runtime.active.value
        val wasLive = Runtime.startedAtMs.value != 0L
        try { stream?.let { if (it.isStreaming) it.stopStream() } } catch (_: Exception) { }
        releaseStream()
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        logEv(if (error != null) "Stopped with error" else "Stopped: ${result ?: "done"}")
        Runtime.result.value = if (error != null) "Failed" else (result ?: "Stopped")
        sessionStart = 0L; secret = ""; endpoint = null
        Runtime.startedAtMs.value = 0L; Runtime.bitrateKbps.value = null; Runtime.file.value = null
        if (error == null) Runtime.state.value = LiveState.OFFLINE  // on error the UI keeps showing ERROR + message
        Runtime.muted.value = false
        if (!wasLive && error == null && result == null) Runtime.state.value = LiveState.OFFLINE
        onFinished?.invoke()
    }

    private fun releaseStream() {
        try { stream?.let { if (it.isOnPreview) it.stopPreview() } } catch (_: Exception) { }
        try { stream?.release() } catch (_: Exception) { }
        stream = null; sig = null; cropFilter = null; cropAdded = false; blurFilter = null; blurActive = false
    }

    private fun redact(s: String?): String {
        var t = s ?: "unknown error"
        if (secret.isNotEmpty()) t = t.replace(secret, "••••")
        return t
    }

    // ---- ConnectChecker (called on library threads) -----------------------------------------------------------

    private fun hostOf(u: String): String = try { val x = Uri.parse(u); x.host + ":" + (if (x.port > 0) x.port else if (x.scheme == "rtmps") 443 else 1935) } catch (e: Exception) { "server" }

    override fun onConnectionStarted(url: String) { main.post { logEv("Handshake started") } }

    override fun onConnectionSuccess() = main.post {
        logEv("Connected — sending video to the server")
        attempts = 0
        Runtime.error.value = null
        if (Runtime.startedAtMs.value == 0L) Runtime.startedAtMs.value = System.currentTimeMillis()
        Runtime.state.value = LiveState.LIVE
        widenSendQueue()
        main.postDelayed({ blurOff() }, 4000)
    }.let { }

    override fun onConnectionFailed(reason: String) {
        main.post { logEv("Connection failed: $reason"); retryOrFail(redact(reason)) }
    }

    override fun onNewBitrate(bitrate: Long) { Runtime.bitrateKbps.value = bitrate / 1000; adaptBitrate() }

    override fun onDisconnect() {
        main.post { if (!userStop && Runtime.state.value == LiveState.LIVE) { logEv("Disconnected from server"); retryOrFail("Connection to the server was lost") } }
    }

    override fun onAuthError() { main.post { logEv("Server rejected the stream key / login"); fail("Authentication failed. Check the stream key and server URL.") } }
    override fun onAuthSuccess() {}

    private fun retryOrFail(reason: String) {
        if (userStop) return
        val s = stream ?: return
        if (attempts >= maxRetries) { fail("$reason (gave up after $maxRetries reconnect attempts)"); return }
        attempts++
        val lim = if (maxRetries == Int.MAX_VALUE) "∞" else maxRetries.toString()
        logEv("Reconnect attempt $attempts/$lim")
        Runtime.state.value = LiveState.RECONNECTING
        Runtime.error.value = "$reason — reconnecting ($attempts/$lim)"
        retryJob?.cancel()
        retryJob = scope.launch {
            try { if (s.isStreaming) s.stopStream() } catch (_: Exception) { }
            delay(minOf(3000L * attempts, 15000L))
            if (userStop) return@launch
            try { endpoint?.let { s.startStream(it) } } catch (e: Exception) { retryOrFail(redact(e.message)) }
        }
    }

    /** Called by the service when the phone gets a network again: retry immediately instead of waiting. */
    fun onNetworkBack() {
        main.post {
            if (userStop || Runtime.state.value != LiveState.RECONNECTING) return@post
            val s = stream ?: return@post
            logEv("Network is back — reconnecting now")
            retryJob?.cancel()
            retryJob = scope.launch {
                try { if (s.isStreaming) s.stopStream() } catch (_: Exception) { }
                delay(500)
                if (userStop) return@launch
                try { endpoint?.let { s.startStream(it) } } catch (e: Exception) { retryOrFail(redact(e.message)) }
            }
        }
    }
}
