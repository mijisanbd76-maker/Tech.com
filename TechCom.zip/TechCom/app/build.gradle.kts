plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.techcom.live"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.techcom.live"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "1.4.0"
    }

    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    // RTMP + MediaCodec encoders, camera / screen / file sources (Apache-2.0)
    implementation("com.github.pedroSG94.RootEncoder:library:2.6.6")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.webkit:webkit:1.11.0")                  // WebViewAssetLoader (Apache-2.0)
    implementation("androidx.security:security-crypto:1.1.0-alpha06") // encrypted stream key (Apache-2.0)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Re-encodes sideways-stored videos to the exact live size (Apache-2.0). Used through reflection only.
    implementation("androidx.media3:media3-common:1.3.1")
    implementation("androidx.media3:media3-effect:1.3.1")
    implementation("androidx.media3:media3-transformer:1.3.1")
}
