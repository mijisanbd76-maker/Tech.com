# Tech.Com — Android app (WebView UI + native RTMP engine)

**STATUS (honest):** The HTML UI was tested in a real browser (83 automated checks passed: every page, button, upload,
playlist, settings, history, bridge messages). The Kotlin/Android code was written WITHOUT an Android SDK, so it has NOT been
compiled or run on a phone. Build it first; send the build log if anything fails and it will be fixed.

## Build the APK
GitHub: upload this folder → Actions → "Build debug APK" → download `TechCom-debug-apk`.
Android Studio: open folder → Build → Build APK(s). Needs JDK 17 (Gradle 8.9 is provided by Studio / the Action).

## How it works
- `app/src/main/assets/index.html` is the whole UI (same file as TechCom_Live_Studio.html).
- `MainActivity` shows it in a WebView and exposes `window.TechComNative` (JavaScript bridge, own page only).
- Bridge: start/stop, native video picker, encrypted stream-key store, permission/battery requests, live state → UI.
- `Engine.kt` + `StreamService.kt`: RootEncoder 2.6.6 camera/screen/file → H.264/AAC → RTMP, foreground service + wake lock
  (keeps streaming with the screen off), reconnect (10 tries), real measured bitrate only.
- Picked videos are previewed through a range-capable local response so seeking works; the key never goes in Intents/logs.

## Build on GitHub (free) — step by step
1. github.com → New repository (public = unlimited free build minutes; private = 2,000 min/month).
2. Upload everything from this zip (keep the folder structure; the `.github` folder must be included).
3. Actions tab → "Build debug APK" → Run workflow. Wait ~5–10 min.
4. Open the finished run → Artifacts → `TechCom-debug-apk` → download, unzip, install the `.apk` on your phone.
Other free options: GitLab CI (free minutes), Codemagic (500 free min/month), Android Studio on a PC (completely free, no limits).

## Streaming with the screen off
Foreground service + CPU wake lock + Wi-Fi lock start with every stream; the service survives swiping the app away.
Network loss: automatic reconnect (unlimited by default) and an immediate retry the moment the network returns.
Cannot be avoided: dead battery or powered-off phone. Screen capture shows black while the screen is off (Android rule);
Video Loop / Video Live are the most reliable modes for long screen-off streams. Some phones (Xiaomi, Oppo, Vivo, Samsung)
also need "Unrestricted" battery for Tech.Com — the Background page has the Allow button.

## Audio / video together
Camera and screen modes encode audio and video in one pipeline. Video-file modes use the encoder library's two file sources;
each playlist item (and each loop) reloads both together so sync resets every pass. This is NOT verified on a phone.
If you hear drift, send: the video's codec/fps/audio sample rate and the Connection log.

## If YouTube does not go live (use the in-app tools)
1. Studio → **Test connection**: if it fails, your network blocks RTMP port 1935 → choose the **YouTube RTMPS (443)** preset.
2. Broadcast Control → **Connection log** (Copy button) shows each step (handshake, connected, failed + reason, retries).
3. **YouTube checklist** button: channel live-enabled, key copied without spaces, wait 10–30 s, press GO LIVE in YouTube Studio.
4. A browser can never go live (no RTMP): the page now says so. Only the APK sends video to YouTube.

## Needs verification on first run (cannot be tested here)
1. Video-file source: `FileBridge` probes RootEncoder's VideoFileSource/AudioFileSource API at runtime; failure shows a clear error.
2. Fit/Fill uses `setAspectRatioMode` if present (notice shown otherwise).
3. `prepareVideo(... fps, iFrameInterval, rotation)`, `MicrophoneSource.unMute()`, `com.pedro.common.ConnectChecker` names.
4. Camera portrait uses 90° rotation; check on device. Live camera/screen preview inside the app is not available (browser only).
5. Preview of picked videos via https://appassets.androidplatform.net/media/<id> (range responses).

## Not implemented
Mic narration mixed into a video stream; "Mic + System" together; Google sign-in/OAuth (needs your Google Cloud client);
YouTube watch-time/subscribers. YouTube numbers need your own Data API v3 key. Vertical live also needs a vertical stream on YouTube's side.

## Licenses (Apache-2.0)
RootEncoder 2.6.6, AndroidX core/activity/lifecycle/webkit/security-crypto, kotlinx-coroutines.

## v1.2.0 changes (screen system-audio fix)
- **Screen + "System only" sound**: system-audio capture is an AudioRecord. Without the *microphone* foreground-service type and the
  RECORD_AUDIO permission, Android silences it (digital silence / short dropouts) once the game is on screen and Tech.Com is in the
  background. The service now declares `mediaProjection|microphone` for every screen mode that has sound, and the permission is
  requested for System / Mic + System too. System audio is encoded 48 kHz stereo 192 kbps.
- No extra GL crop pass when zoom = 1 (less GPU load while the game runs). Larger RTMP send queue (~8 s) so audio frames are not
  dropped in short network bursts. The Connection log now shows the audio path used ("Audio: system (playback capture) 48 kHz stereo 192 kbps").
- Leaving the app only pauses the small preview player; the live runs in the foreground service (Video Loop / Video Live / Screen / Camera).
- Still NOT compiled or run here (no Android SDK). If the build fails, send the log.

## v1.3.0 changes (video size in live)
- Evidence: the live of a 16:9 (landscape) video on a 9:16 output showed the picture as a small band in the middle of the screen
  (black bars above/below) = "Fit" mode. **Fill is now the default** (also migrates saved settings once), so a video fills the whole
  vertical screen like a Short; a wide video loses its left/right edges. Choose "Fit (letterbox)" in Studio to see the whole picture.
- The Connection log now prints "Picture: Fill ..." and warns if this encoder version did not apply it.
- Screen "System only" sound: the recordings show short digital-silence gaps (about 14 ms, ~15 per second) both in the phone's own
  recording and in the YouTube replay, i.e. the gaps already exist in the captured system audio. See chat notes for the A/B test.
